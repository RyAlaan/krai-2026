#include "Variable.h"

void MoveRobot() {
  // FIX: pakai rxStruct.Wr (bukan .W — field tidak ada)
  float vx = rxStruct.Vx;
  float vy = rxStruct.Vy;
  float wr = rxStruct.Wr;

  // Hitung setpoint tiap roda via inverse kinematics
  // Satuan input = satuan output Vwheel (tidak ada konversi di dalam IK)
  // Gunakan satuan RPM langsung: K 0 150 0 → Vwheel ≈ ±150 RPM
  calc.inverse_kinematics(vx, vy, wr);

  Setpoint1 = calc.Vwheel[0];
  Setpoint2 = calc.Vwheel[1];
  Setpoint3 = calc.Vwheel[2];
  Setpoint4 = calc.Vwheel[3];

  // Eksekusi motor: pakai output PID jika aktif, open-loop jika tidak
  if (PID_on) {
    rangkabawah.Movement(
      constrain(Output1, -4095, 4095),
      constrain(Output2, -4095, 4095),
      constrain(Output3, -4095, 4095),
      constrain(Output4, -4095, 4095)
    );
  } else {
    PID_reset();
    rangkabawah.Movement(
      constrain(calc.Vwheel[0], -4095, 4095),
      constrain(calc.Vwheel[1], -4095, 4095),
      constrain(calc.Vwheel[2], -4095, 4095),
      constrain(calc.Vwheel[3], -4095, 4095)
    );
  }
  // TIDAK ada forward_kinematics di sini — sudah dipindah ke loop()
}
