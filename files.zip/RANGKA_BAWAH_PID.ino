#include "Variable.h"

Motor roda1(sel_fr, pwm_fr);
Motor roda2(sel_fl, pwm_fl);
Motor roda3(sel_bl, pwm_bl);
Motor roda4(sel_br, pwm_br);

float norm_(float yaw) {
  return fmod((yaw + 180), 360) - 180;
}

void setup() {
  Serial.begin(115200);
  Motor::beginPWM(20000, 12);

  pinMode(LED, OUTPUT);
  digitalWrite(LED, LOW);
  pinMode(rpwm_mid, OUTPUT);
  pinMode(lpwm_mid, OUTPUT);

  rangkabawah      = LowerPart(sel_fr, pwm_fr, sel_fl, pwm_fl, sel_bl, pwm_bl, sel_br, pwm_br);
  rangkabawahtengah = LowerPartMid(rpwm_mid, lpwm_mid);

  calc = Kinematics(a1, a2, a3, a4, r, R);
  calc.set_ideal_value(a1_ideal, a2_ideal, a3_ideal, a4_ideal);
  calc.PPR = PPR;
  calc.init();
  calc.update_angle(0);

  PID_init();
}

void loop() {
  /* =============== TERIMA PERINTAH TUNING =============== */
  inputCommand();

  /* ===================== MAIN PROGRAM =================== */
  if (!stop) {
    if (millis() - input_prevmillis >= inputrate) {

      // 1. Baca encoder
      prev_fr_tics = fr_tics; prev_fl_tics = fl_tics;
      prev_bl_tics = bl_tics; prev_br_tics = br_tics;
      fr_tics = ENCFR.read(); fl_tics = ENCFL.read();
      bl_tics = ENCBL.read(); br_tics = ENCBR.read();
      prev_Timing = Timing;
      Timing = micros();

      // 2. Hitung kecepatan roda dalam RPM
      float dt = ((float)(Timing - prev_Timing)) / 1.0e6;
      Vreal1 = ((fr_tics - prev_fr_tics) / dt) / PPR * 60.0;
      Vreal2 = ((fl_tics - prev_fl_tics) / dt) / PPR * 60.0;
      Vreal3 = ((bl_tics - prev_bl_tics) / dt) / PPR * 60.0;
      Vreal4 = ((br_tics - prev_br_tics) / dt) / PPR * 60.0;

      // 3. Filter Kalman
      Vfilt1 = Roda_1.updateEstimate(Vreal1);
      Vfilt2 = Roda_2.updateEstimate(Vreal2);
      Vfilt3 = Roda_3.updateEstimate(Vreal3);
      Vfilt4 = Roda_4.updateEstimate(Vreal4);

      // 4. Inverse kinematics → isi Setpoint, gerakkan motor
      MoveRobot();

      // 5. Hitung PID (output tersimpan di Output1..4, dipakai di MoveRobot)
      PID_compute();

      // 6. Forward kinematics di sini saja (bukan di MoveRobot)
      calc.forward_kinematics(Vfilt1, Vfilt2, Vfilt3, Vfilt4, false);
      calc.forward_kinematics(ENCFR.read(), ENCFL.read(), ENCBL.read(), ENCBR.read(), true);

      // 7. Update data TX
      txStruct.X     = (float)calc.dist_travel[0];
      txStruct.Y     = (float)calc.dist_travel[1];
      txStruct.tetha = norm_((float)calc.dist_travel[2]);
      txStruct.Vx    = (float)calc.Vreal[0];
      txStruct.Vy    = (float)calc.Vreal[1];
      txStruct.Wr    = (float)calc.Vreal[2];

      // 8. Debug Serial
      Serial.print("Setpoint:"); Serial.print(Setpoint1);
      Serial.print(",RPM:");     Serial.print(Vfilt1);
      Serial.print(",PWM:");     Serial.print(Output1);
      Serial.println();

      input_prevmillis = millis();
    }

  } else {
    // STOP: reset encoder & odometri jika diminta
    if (reset_data) {
      ENCFR.readAndReset();
      ENCFL.readAndReset();
      ENCBL.readAndReset();
      ENCBR.readAndReset();
      calc.dist_travel[0] = 0;
      calc.dist_travel[1] = 0;
      calc.dist_travel[2] = 0;
      reset_data = false;
    }
    rxStruct.Vx = 0;
    rxStruct.Vy = 0;
    rxStruct.Wr = 0;
    rangkabawah.Movement(0, 0, 0, 0);
  }
}

void receive() {
  if (myTransfer.available()) {
    int16_t recSize = 0;
    recSize = myTransfer.rxObj(rxStruct, recSize);
    if (rxStruct.cmd == 'a')      stop = false;
    else if (rxStruct.cmd == 'b') stop = true;
  }
}

void transfer() {
  if (millis() - timePeriode >= 15) {
    int16_t sendSize = 0;
    struct __attribute__((packed)) STRUCT {
      float pwm1 = calc.Vwheel[0];
      float pwm2 = calc.Vwheel[1];
      float pwm3 = calc.Vwheel[2];
      float pwm4 = calc.Vwheel[3];
    } testStruct;
    sendSize = myTransfer.txObj(testStruct, sendSize);
    myTransfer.sendData(sendSize);
    timePeriode = millis();
  }
}
