#include "Variable.h"

// Flag: true = pakai Setpoint manual (R/T), false = pakai IK dari MoveRobot()
bool manualMode = false;

void inputCommand() {
  if (!Serial.available()) return;

  String line = Serial.readStringUntil('\n');
  line.trim();
  if (!line.length()) return;

  // Tokenize
  String tok[10];
  int count = 0, start = 0;
  for (int i = 0; i <= (int)line.length() && count < 10; i++) {
    if (i == (int)line.length() || line.charAt(i) == ' ') {
      tok[count++] = line.substring(start, i);
      start = i + 1;
    }
  }

  char cmd = toupper(tok[0].charAt(0));

  // "A <Kp> <Ki> <Kd>" — tuning semua motor
  if (cmd == 'A' && count == 4) {
    float p = tok[1].toFloat();
    float i = tok[2].toFloat();
    float d = tok[3].toFloat();

    settlingStart = 0; settlingDone = false; settlingTime = 0;
    Kp1=Kp2=Kp3=Kp4=p; Ki1=Ki2=Ki3=Ki4=i; Kd1=Kd2=Kd3=Kd4=d;
    motor1.SetTunings(p,i,d); motor2.SetTunings(p,i,d);
    motor3.SetTunings(p,i,d); motor4.SetTunings(p,i,d);

    Serial.print(">> Tuning -> Kp:"); Serial.print(p);
    Serial.print(" Ki:"); Serial.print(i);
    Serial.print(" Kd:"); Serial.println(d);
  }

  // "T <roda> <RPM>" — test satu roda, roda lain diam
  // Contoh: "T 1 100" → roda 1 = 100 RPM, roda 2/3/4 = 0
  else if (cmd == 'T' && count == 3) {
    int roda = tok[1].toInt();
    float rpm  = tok[2].toFloat();

    manualMode = true; // matikan MoveRobot() override
    Setpoint1 = 0; Setpoint2 = 0;
    Setpoint3 = 0; Setpoint4 = 0;

    switch(roda) {
      case 1: Setpoint1 = rpm; break;
      case 2: Setpoint2 = rpm; break;
      case 3: Setpoint3 = rpm; break;
      case 4: Setpoint4 = rpm; break;
      default:
        Serial.println("Roda harus 1-4");
        return;
    }
    settlingStart = 0; settlingDone = false; settlingTime = 0;
    Serial.print(">> Test roda "); Serial.print(roda);
    Serial.print(" -> "); Serial.print(rpm); Serial.println(" RPM");
  }

  // "R <RPM1> <RPM2> <RPM3> <RPM4>" — set RPM semua roda manual
  // Contoh: "R 100 100 100 100"
  else if (cmd == 'R' && count == 5) {
    manualMode = true; // matikan MoveRobot() override
    Setpoint1 = tok[1].toFloat();
    Setpoint2 = tok[2].toFloat();
    Setpoint3 = tok[3].toFloat();
    Setpoint4 = tok[4].toFloat();

    settlingStart = 0; settlingDone = false; settlingTime = 0;
    Serial.print(">> RPM Manual: ");
    Serial.print(Setpoint1); Serial.print(" | ");
    Serial.print(Setpoint2); Serial.print(" | ");
    Serial.print(Setpoint3); Serial.print(" | ");
    Serial.println(Setpoint4);
  }

  // "K <Vx> <Vy> <Wr>" — gerak robot via inverse kinematics
  // Contoh: "K 0.5 0 0" → maju 0.5 m/s
  else if (cmd == 'K' && count == 4) {
    manualMode = false; // aktifkan MoveRobot() kembali
    settlingStart = 0; settlingDone = false; settlingTime = 0;
    Vx = tok[1].toFloat();
    Vy = tok[2].toFloat();
    Wr = tok[3].toFloat();

    Serial.print(">> K -> Vx:"); Serial.print(Vx);
    Serial.print(" Vy:"); Serial.print(Vy);
    Serial.print(" Wr:"); Serial.println(Wr);
  }

  // "W" — start
  else if (cmd == 'W') {
    stop = false;
    Serial.println(">> START <<");
  }

  // "Q" — stop
  else if (cmd == 'Q') {
    stop = true;
    manualMode = false;
    Vx = 0; Vy = 0; Wr = 0;
    Serial.println(">> STOP <<");
  }

  else {
    Serial.println("Perintah:");
    Serial.println("  W              -> Start");
    Serial.println("  Q              -> Stop");
    Serial.println("  A <Kp> <Ki> <Kd>   -> Tuning PID semua roda");
    Serial.println("  T <roda> <RPM>     -> Test 1 roda (1-4)");
    Serial.println("  R <R1> <R2> <R3> <R4> -> Set RPM manual semua roda");
    Serial.println("  K <Vx> <Vy> <Wr>   -> Gerak via IK (m/s, rad/s)");
  }
}
