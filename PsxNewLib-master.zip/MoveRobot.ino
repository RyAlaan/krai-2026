#include <cmath>
#include "Variable.h"

/* Untuk Otonom */
void MoveRobot() {
  float wheel_radius = r / 100.0; // cm → m

  calc.inverse_kinematics(Vx, Vy, Wr);

  // Konversi Vwheel (m/s) → RPM sebagai Setpoint PID
  Setpoint1 = calc.Vwheel[0] / (2 * PI * wheel_radius) * 60;
  Setpoint2 = calc.Vwheel[1] / (2 * PI * wheel_radius) * 60;
  Setpoint3 = calc.Vwheel[2] / (2 * PI * wheel_radius) * 60;
  Setpoint4 = calc.Vwheel[3] / (2 * PI * wheel_radius) * 60;
}
