void PID_init(){
  motor1.SetOutputLimits(-4095, 4095);
  motor2.SetOutputLimits(-4095, 4095);
  motor3.SetOutputLimits(-4095, 4095);
  motor4.SetOutputLimits(-4095, 4095);

  motor1.SetSampleTimeUs(inputrate * 1000);
  motor2.SetSampleTimeUs(inputrate * 1000);
  motor3.SetSampleTimeUs(inputrate * 1000);
  motor4.SetSampleTimeUs(inputrate * 1000);

  motor1.SetTunings(Kp1, Ki1, Kd1);
  motor2.SetTunings(Kp2, Ki2, Kd2);
  motor3.SetTunings(Kp3, Ki3, Kd3);
  motor4.SetTunings(Kp4, Ki4, Kd4);

  motor1.SetMode(motor1.Control::automatic);
  motor2.SetMode(motor2.Control::automatic);
  motor3.SetMode(motor3.Control::automatic);
  motor4.SetMode(motor4.Control::automatic);
}

void PID_compute() {
  motor1.Compute();
  motor2.Compute();
  motor3.Compute();
  motor4.Compute();

  rangkabawah.Movement(
    constrain(Output1, -4095, 4095),
    constrain(Output2, -4095, 4095),
    constrain(Output3, -4095, 4095),
    constrain(Output4, -4095, 4095)
  );
}

void PID_reset(){
  motor1.Reset();
  motor2.Reset();
  motor3.Reset();
  motor4.Reset();
}
